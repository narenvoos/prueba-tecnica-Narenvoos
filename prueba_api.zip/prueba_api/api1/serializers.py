from .models import Createuser
from rest_framework import serializers

class CreateuserSerializer(serializers.ModelSerializer):

    class Meta:
        model = Createuser
        fields = '__all__'