from django.urls import path
from . import views

urlpatterns = [
    path('<int:pk>', views.NoticiasCrudList.as_view()),
    path('', views.NoticiasList.as_view()),
    path('', views.NoticiasCreateList.as_view()),
]