from django.db import models

class Createuser(models.Model):
    nombre_completo = models.CharField(max_length=255)
    correo = models.EmailField(max_length=255)
    contraseña = models.CharField(max_length=20)
    direccion = models.CharField(max_length=50)
    telefono = models.CharField(max_length=20)
    fecha_de_nacimiento = models.DateTimeField()

    def __str__(self):
        return self.nombre_completo