from noticias.models import Noticias
from .models import Noticias
from .serializers import NoticiasSerializer
from django.shortcuts import render
from rest_framework import generics



class NoticiasCrudList(generics.RetrieveUpdateDestroyAPIView):
    queryset = Noticias.objects.all()
    serializer_class = NoticiasSerializer

class NoticiasList(generics.ListAPIView):
    queryset = Noticias.objects.all()
    serializer_class = NoticiasSerializer

class NoticiasCreateList(generics.CreateAPIView):
    queryset = Noticias.objects.all()
    serializer_class = NoticiasSerializer
