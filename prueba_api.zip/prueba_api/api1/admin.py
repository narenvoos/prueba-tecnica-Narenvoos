from django.contrib import admin
from .models import Createuser
# Register your models here.
admin.site.register(Createuser)
