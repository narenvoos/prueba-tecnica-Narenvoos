import site
from django.contrib import admin
from .models import Noticias
# Register your models here.}

admin.site.register(Noticias)
