# #api/authentication/ login/ [name='rest_login']
# from django.urls import path

# urlpatterns = [
#     path('login/', name='rest_login'),
# ]